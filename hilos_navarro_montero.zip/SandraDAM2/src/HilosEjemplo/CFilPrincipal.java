package HilosEjemplo;

import java.util.Scanner;

public class CFilPrincipal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("Seleccione una opción:");
            System.out.println("1. Modificar la temporización del proceso hijo para que termine antes que el padre.");
            System.out.println("2. Modificar la temporización del proceso hijo para que termine después que el padre.");
            System.out.println("3. Asegurar que el padre termine después de cualquiera de sus procesos hijos.");
            System.out.println("4. Iniciar la ejecución de procesos hijos con temporizaciones diferentes.");
            System.out.println("0. Salir");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    modificarTemporizacionAntes();
                    break;
                case 2:
                    modificarTemporizacionDespues();
                    break;
                case 3:
                    asegurarPadreDespues();
                    break;
                case 4:
                    iniciarProcesosConTemporizacionesDiferentes();
                    break;
                case 0:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    private static void modificarTemporizacionAntes() {
        CFil hijo = new CFil("Hijo");
        CFil padre = new CFil("Padre");
        hijo.setTemporizacion(2000);
        padre.setTemporizacion(5000);
		
        hijo.start();
        padre.start();		            

        try {
            hijo.join();
        	padre.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println();
    }

    private static void modificarTemporizacionDespues() {
        CFil padre = new CFil("Padre");
        CFil hijo = new CFil("Hijo");
        padre.setTemporizacion(2000);
		hijo.setTemporizacion(5000);

        padre.start();		            
		hijo.start();

        try {
        	padre.join();
            hijo.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println();
    }

    private static void asegurarPadreDespues() {
        CFil hijo = new CFil("Hijo");
        hijo.start();

        try {
            hijo.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Proceso padre terminado.");
        System.out.println();
    }

    private static void iniciarProcesosConTemporizacionesDiferentes() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el número de procesos hijos: ");
        int numProcesos = scanner.nextInt();

        if (numProcesos <= 0 || numProcesos > 10) {
            System.out.println("Número de procesos no válido.");
            return;
        }

        CFil[] hijos = new CFil[numProcesos];

        for (int i = 0; i < numProcesos; i++) {
            hijos[i] = new CFil("Hijo" + (i + 1));
            hijos[i].setTemporizacion(1000 / (i + 1)); // Temporización diferente para cada hijo
            hijos[i].start();
        }

        // Espera a que todos los procesos hijos terminen
        for (CFil hijo : hijos) {
            try {
                hijo.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Proceso padre terminado.");
        System.out.println();
    }
}
