package HilosEjemplo;

import java.util.*;

class CFil extends Thread {
    private String nombre;
    private int temporizacion;

    public CFil(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setTemporizacion(int temporizacion) {
        this.temporizacion = temporizacion;
    }

    @Override
    public void run() {
        try {
            System.out.println(nombre + " iniciado.");
            Thread.sleep(temporizacion);
            System.out.println(nombre + " terminado.");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
