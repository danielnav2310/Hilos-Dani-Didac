package Hilos;

public class concurrencia extends Thread {
	public concurrencia (String str) {
		super(str);
	}
	// gets
	// sets
	
	// ejecucion tarea concurrente
	
	public void run() {
		for (int i = 0; i<10; i++) {
			System.out.print(i + " " + getName());		
			
			try {
				sleep((long) (Math.random()*1000));	
				
			} catch (Exception e) {
				System.out.print("Error");
			}
		}
		System.out.print("Fin");
	}
}
