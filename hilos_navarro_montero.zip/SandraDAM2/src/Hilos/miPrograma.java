package Hilos;

public class miPrograma {
	public static void main(String[] args) {
		concurrencia tarea, tarea2;		

		tarea = new concurrencia("Dani ");
		tarea2 = new concurrencia("Navarro ");
				
		tarea.start();
		tarea2.start();
	}
}
